<?php 
/*
Plugin Name:Library Book
Plugin Uri: http://www.google.com
Description: This can be add books by author and publisher with custom fields as price,star rating etc. 
Version:1.0 
Author: Mehul Patel
Author Uri: http://www.google.com
*/
?>
<?php 

if ( ! defined( 'BOOK_BASE_FILE' ) )
    define( 'BOOK_BASE_FILE', __FILE__ );
if ( ! defined( 'BK_BASE_DIR' ) )
    define( 'BK_BASE_DIR', dirname( BOOK_BASE_FILE ) );
if ( ! defined( 'BOOK_PLUGIN_URL' ) )
    define( 'BOOK_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
require_once (dirname(__FILE__).'/includes/templates/functions.php');

/*Start register post type book */
add_action( 'init', 'custom_post_type_book', 0 );

function custom_post_type_book()
{
// Set UI labels for book Post Type
	$labels = array(
		'name'                => _x( 'Book', 'Post Type General Name', 'twentyseventeen' ),
		'singular_name'       => _x( 'Book', 'Post Type Singular Name', 'twentyseventeen' ),
		'menu_name'           => __( 'Book', 'twentyseventeen' ),
		'parent_item_colon'   => __( 'Parent Book', 'twentyseventeen' ),
		'all_items'           => __( 'All Book', 'twentyseventeen' ),
		'view_item'           => __( 'View Book', 'twentyseventeen' ),
		'add_new_item'        => __( 'Add New Book', 'twentyseventeen' ),
		'add_new'             => __( 'Add Book', 'twentyseventeen' ),
		'edit_item'           => __( 'Edit Book', 'twentyseventeen' ),
		'update_item'         => __( 'Update Book', 'twentyseventeen' ),
		'search_items'        => __( 'Search Book', 'twentyseventeen' ),
		'not_found'           => __( 'Not Found', 'twentyseventeen' ),
		'not_found_in_trash'  => __( 'Not found in Trash', 'twentyseventeen' ),
	);
	
// Set other options for book Post Type
	
	$args = array(
		'label'               => __( 'Book', 'twentyseventeen' ),
		'description'         => __( 'Book and reviews', 'twentyseventeen' ),
		'labels'              => $labels,
		'supports'            => array( 'title','excerpt','editor'),
		'taxonomies'          => array( 'genres' ),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 4,
		'can_export'          => true,
		'has_archive'         => false,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'menu_icon'           => 'dashicons-book',
		'rewrite'            => array( 'slug' => 'book','with_front'  => false),
		'capability_type'     => 'post',
	);
	
	// Registering book  Post Type
	register_post_type( 'book', $args );
}


function register_book_taxonomies() {

	$taxonomies = array(
		array(
			'slug'         => 'author',
			'single_name'  => 'Author',
			'plural_name'  => 'Author',
			'post_type'    => 'book',
			'rewrite'      => array( 'slug' => 'author' ),
		),
		array(
			'slug'         => 'publisher',
			'single_name'  => 'Publisher',
			'plural_name'  => 'Publisher',
			'post_type'    => 'book',
			'rewrite'      => array( 'slug' => 'publisher' ),
		),
		
	);

	foreach( $taxonomies as $taxonomy ) {
		$labels = array(
			'name' => $taxonomy['plural_name'],
			'singular_name' => $taxonomy['single_name'],
			'search_items' =>  'Search ' . $taxonomy['plural_name'],
			'all_items' => 'All ' . $taxonomy['plural_name'],
			'parent_item' => 'Parent ' . $taxonomy['single_name'],
			'parent_item_colon' => 'Parent ' . $taxonomy['single_name'] . ':',
			'edit_item' => 'Edit ' . $taxonomy['single_name'],
			'update_item' => 'Update ' . $taxonomy['single_name'],
			'add_new_item' => 'Add New ' . $taxonomy['single_name'],
			'new_item_name' => 'New ' . $taxonomy['single_name'] . ' Name',
			'menu_name' => $taxonomy['plural_name']
		);
		
		$rewrite = isset( $taxonomy['rewrite'] ) ? $taxonomy['rewrite'] : array( 'slug' => $taxonomy['slug'] );
		$hierarchical = isset( $taxonomy['hierarchical'] ) ? $taxonomy['hierarchical'] : true;
	
		register_taxonomy( $taxonomy['slug'], $taxonomy['post_type'], array(
			'hierarchical' => $hierarchical,
			'labels' => $labels,
			'show_ui' => true,
			'query_var' => true,
			'rewrite' => $rewrite,
		));
	}
	
}
add_action( 'init', 'register_book_taxonomies' );

add_action('admin_menu', 'book_plugin_shortcode_menu');
function book_plugin_shortcode_menu()
{
	add_menu_page( 'Book Shortcode', 'Book Shortcode', 'manage_options', 'book-shortcode', 'call_shortcode_page' );
}

function call_shortcode_page()
{
	echo '<div class="wrap">';
	echo '<h1>Add [test] Short code to display Library Book search form in any post or page.</h1>';
	echo '</div>';
}


add_filter( 'template_include', 'rc_tc_template_chooser');
 
/*
|--------------------------------------------------------------------------
| PLUGIN FUNCTIONS
|--------------------------------------------------------------------------
*/
 
/**
 * Returns template file
 *
 * @since 1.0
 */
 
function rc_tc_template_chooser( $template ) {
 
 
    // Post ID
    $post_id = get_the_ID();
 
    // For all other CPT
	
    if ( get_post_type( $post_id ) != 'book' ) {
		
		//exit;
        return $template;
    }
 
    // Else use custom template
    if ( is_single() ) {
        return rc_tc_get_template_hierarchy( 'single' );
    }
 
}

function rc_tc_get_template_hierarchy( $template ) {
 
    // Get the template slug
    $template_slug = rtrim( $template, '.php' );
    $template = $template_slug . '.php';
 
    // Check if a custom template exists in the theme folder, if not, load the plugin template file
    if ( $theme_file = locate_template( array( 'plugin_template/' . $template ) ) ) {
        $file = $theme_file;
    }
    else {
        $file = BK_BASE_DIR . '/includes/templates/' . $template;
    }
 
    return apply_filters( 'rc_repl_template_' . $template, $file );
}

add_action('add_meta_boxes','text_field_metaa');

function text_field_metaa()
{

 add_meta_box('bookid',__('Price'),'display_price_fields','book','normal','core');
 add_meta_box('ratingid', __('Rating'), 'display_rating_fields', 'book','normal','core');
}

function display_price_fields($post)
{
$value= get_post_meta($post->ID,'bkprice',true);	
?>
<input type="text" name="bkprice" value="<?php echo esc_attr($value);?>" />
<?php 
}


function display_rating_fields($post)
{
$value_rating= get_post_meta($post->ID,'rating',true);	
?>	
<input type="number" name="rating" max="5" step="any" value="<?php echo esc_attr($value_rating);?>" />
<?php 
}

function save_price_meta_boxe( $post_id ) {

    // If this is an autosave, our form has not been submitted, so we don't want to do anything.
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }

    // Check the user's permissions.
    if ( isset( $_POST['post_type'] ) && 'book' == $_POST['post_type'] ) {

        if ( ! current_user_can( 'edit_page', $post_id ) ) {
            return;
        }

    }
    else {

        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }
    }

    /* OK, it's safe for us to save the data now. */

    // Make sure that it is set.
    if ( ! isset( $_POST['bkprice'] ) ) {
        return;
    }
	
	if ( ! isset( $_POST['rating'] ) ) {
        return;
    }

    // Sanitize user input.
    $price_data = sanitize_text_field( $_POST['bkprice'] );
    $rating_data = sanitize_text_field( $_POST['rating'] );

    // Update the meta field in the database.
    update_post_meta( $post_id, 'bkprice', $price_data );
    update_post_meta( $post_id, 'rating', $rating_data );
}

add_action( 'save_post', 'save_price_meta_boxe' );

/*
|--------------------------------------------------------------------------
| FILTERS
|--------------------------------------------------------------------------
*/
 
add_filter( 'template_include', 'rc_tc_template_chooser' );

function form_creation(){
?>
<form action="<?php echo site_url() ?>/wp-admin/admin-ajax.php" method="POST" id="filter">
	 <h2>Book Search</h2>
	<div class="left_form">
	<ul>
	<li>
	<label>Book Name:</label>
	<input type="text" name="bkname" value="" />
	</li>
	
	<li>
	<label>Author:</label>
	<input type="text" name="authname" value="" />
	</li>
	</ul>
	</div>
	<div class="right_form">
	<ul>
	<li>
	<label>Publisher:</label>
	<?php
		if( $terms = get_terms( 'publisher', 'orderby=name' ) ) : // to make it simple I use default categories
			echo '<select name="pubtax"><option>Select Publisher...</option>';
			foreach ( $terms as $term ) :
				echo '<option value="' . $term->term_id . '">' . $term->name . '</option>'; // ID of the category as the value of an option
			endforeach;
			echo '</select>';
		endif;
	?>
	</li>
	<li>
	<label>Rating:</label>
	<?php
	global $post;
	$rating_arr=array(
	'post_type' => 'book',
	'post_status' => 'publish',
	'posts_per_page' => -1
	);
	
	$rating_obj= new WP_Query($rating_arr);
	echo '<select name="authtax"><option>Select Rating...</option>';
	while($rating_obj->have_posts())
		
		{
			$rating_obj->the_post();
			$get_postmeta=get_post_meta($post->ID,'rating',true);
			print_r($get_postmeta);
			echo '<option value="' . $get_postmeta[0] . '">' . $get_postmeta[0] . '</option>'; // ID of the category as the value of an option
		}
	echo '</select>';
	?>
	</li>
	<li>
	<label>Price:</label>
	<input type="text" name="bkprice" value="" />
	</li>
	</ul>
	
	<button type="submit">Search</button>
	<input type="hidden" name="action" value="myfilter">
	</div>
</form>
<div id="response"></div>
<script>
jQuery(function($){
	$('#filter').submit(function(){
		var filter = $('#filter');
	
		$.ajax({
			url:filter.attr('action'),
			data:filter.serialize(), // form data
			type:filter.attr('method'), // POST
			beforeSend:function(xhr){
				filter.find('button').text('Processing...'); // changing the button label
			},
			
			success:function(data){
				//alert('hi');
				filter.find('button').text('Search'); // changing the button label back
				$('#response').html(data); // insert data
			},
			error: function(data1) {
					debugger;
          alert('Error occurs!');
       }
		});
		return false;
	});
});
</script>
 
<?php
}
add_shortcode('test', 'form_creation');
?>