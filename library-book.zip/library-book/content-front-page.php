<?php
/**
 * Displays content for front page
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

?>
<form action="<?php echo site_url() ?>/wp-admin/admin-ajax.php" method="POST" id="filter">
	<?php
		if( $terms = get_terms( 'author', 'orderby=name' ) ) : // to make it simple I use default categories
			echo '<select name="categoryfilter"><option>Select category...</option>';
			foreach ( $terms as $term ) :
				echo '<option value="' . $term->term_id . '">' . $term->name . '</option>'; // ID of the category as the value of an option
			endforeach;
			echo '</select>';
		endif;
	?>
	<input type="text" name="bkprice" placeholder="Title" />
	<button type="submit">Apply filter</button>
	<input type="hidden" name="action" value="myfilter">
</form>
<div id="response"></div>
<script>
jQuery(function($){
	$('#filter').submit(function(){
		var filter = $('#filter');
	
		$.ajax({
			url:filter.attr('action'),
			data:filter.serialize(), // form data
			type:filter.attr('method'), // POST
			beforeSend:function(xhr){
				filter.find('button').text('Processing...'); // changing the button label
			},
			success:function(data){
				alert('hi');
				filter.find('button').text('Apply filter'); // changing the button label back
				$('#response').html(data); // insert data
			},
			error: function(data1) {
					debugger;
          alert('Error occurs!');
       }
		});
		return false;
	});
});
</script>
