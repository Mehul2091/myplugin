<?php
/**
 * Twenty Seventeen functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 */

/**
 * Twenty Seventeen only works in WordPress 4.7 or later.
 */
if ( version_compare( $GLOBALS['wp_version'], '4.7-alpha', '<' ) ) {
	require get_template_directory() . '/inc/back-compat.php';
	return;
}
/* Add custom plugin style*/

  function add_my_css_and_my_js_files(){
       
        wp_enqueue_style( 'your-stylesheet-name', plugins_url('/css/styles.css', __FILE__), false, '1.0.0', 'all');
    }
    add_action('wp_enqueue_scripts', "add_my_css_and_my_js_files");

function search_filter_function(){
	
	
	 $rating=$_POST['authtax'];
	 $bkprice=$_POST['bkprice'];
	 $pubisher=$_POST['pubtax'];
	 $author=$_POST['authname'];
	 $args =array(
			'post_type' => book,
			 's'        => $_POST['bkname'],
			'meta_query' => array(
				'relation' => 'OR',
				array(
					'key'     => 'rating',
					'value'   => $_POST['authtax'],
					'compare' => 'LIKE'
				),
				array(
					'key'     => 'bkprice',
					'value'   => $_POST['bkprice'],
					'compare' => 'LIKE'
				)
			),
			'tax_query' => array(                     
			'relation' => 'OR',                      
			  array(
				'taxonomy' => 'publisher',                
				'field' => 'term_id',                    
				'terms' => $pubisher                     
			  ),
			  array(
				'taxonomy' => 'author',                
				'field' => 'name',                    
				'terms' => $author  
				               
			  )
			  )
		);

	
 
	?>
	<table border="1" style="margin-top:22px;float:right;">
	<tr>
    <td>
	
	<table border="0">
	<tr>
	<th>No</th>
	<th>Book Name</th>
	<th>Price</th>
	<th>Author</th>
	<th>Publisher</th>
	<th>Rating</th>
	</tr>
	<?php 
	$i=1;
	$query = new WP_Query( $args );
	//echo '<pre>';
	//print_r($args);
	if( $query->have_posts() ) :
		while( $query->have_posts() ): $query->the_post();
			global $post;
			//echo $post->ID;
			$prating=get_post_meta($post->ID, 'rating', true);
			$pprice=get_post_meta($post->ID, 'bkprice', true);
			$term_author = get_the_terms( $post->ID, 'author' );
			$terms_publisher = get_the_terms( $post->ID, 'publisher' );
			
			
			echo '<tr>';
			echo '<td>' . $i . '</td>';
			echo '<td><a href="'.get_permalink().'">' . $post->post_title . '</a></td>';
			echo '<td>' .'$'. $pprice . '</td>';
			foreach($term_author as $term_authors) {
			echo '<td>' . $term_authors->name . '</td>';
			}
			foreach($terms_publisher as $terms_publishers) {
			echo '<td>' . $terms_publishers->name . '</td>';
			}
			echo '<td>';
			for($x=1;$x<=$prating;$x++) {
			
			echo '<img src="'.plugin_dir_url( __FILE__ ).'/images/star-fill.png" />';
			}
			
			
			while ($x<=5) {
				echo '<img src="'.plugin_dir_url( __FILE__ ).'/images/star-empty.png" />';
				$x++;
			}
			echo  '</td>';
			echo '</tr>';
		$i++;	
		endwhile;
		wp_reset_postdata();
	?>	</table>
		</td>
	  </tr>
	</table>
	<?php 
	else :
		echo 'No posts found';
	endif;
 
	die();
}
 
 
add_action('wp_ajax_myfilter', 'search_filter_function'); 
add_action('wp_ajax_nopriv_myfilter', 'search_filter_function');