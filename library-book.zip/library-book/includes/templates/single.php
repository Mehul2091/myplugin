<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

get_header(); ?>

<div class="wrap">
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
            <h1><?php the_title();?></h1>
			<?php
			/* Start the Loop */
			while ( have_posts() ) : the_post();
			$author = get_the_terms( $post->ID, 'author' );
			echo '<p><span>Author:  </span>';
			$publisher = get_the_terms( $post->ID, 'publisher' );
			$acount=count($author);
			$ac=1;
			$pcount=count($publisher);
			$pc=1;
			foreach($author as $authors) {
			if($acount != $ac){	
			echo '<a href="'.get_term_link($authors->term_id).'">'.$authors->name.'</a>';
			}else
			{
			echo '<a href="'.get_term_link($authors->term_id).'">'.$authors->name.'</a>';	
			}
			$ac++;
			}
			echo  '</p>';
			echo '<p><span>Publisher:  </span>';
			foreach($publisher as $publishers) {
			if($pcount != $pc){	
			echo '<a href="'.get_term_link($publishers->term_id).'">'.$publishers->name.'</a>';
			}else
			{
			echo '<a href="'.get_term_link($publishers->term_id).'">'.$publishers->name.'</a>';	
			}
			$pc++;
			}
            echo  '</p>';		
			$prating=get_post_meta($post->ID, 'rating', true);
			$pprice=get_post_meta($post->ID, 'bkprice', true);
			echo '<p><span>Price: </span>'.'$'.$pprice;
			
			echo '<p><span class="rating-img">Rating: </span>';
			for($x=1;$x<=$prating;$x++) {
			
			echo '<img src="'.plugin_dir_url( __FILE__ ).'/images/star-fill.png" />';
			}
			
			if (strpos($prating,'.')) {
				echo '<img src="path/to/half/star.png" />';
				$x++;
			}
			
			while ($x<=5) {
				echo '<img src="'.plugin_dir_url( __FILE__ ).'/images/star-empty.png" />';
				$x++;
			}
			echo '</p>';
			echo '<p><span>Description: </span>';
			the_content();
			echo '</p>';
			endwhile; // End of the loop.
			?>

		</main><!-- #main -->
	</div><!-- #primary -->
	<?php get_sidebar(); ?>
</div><!-- .wrap -->

<?php get_footer();
